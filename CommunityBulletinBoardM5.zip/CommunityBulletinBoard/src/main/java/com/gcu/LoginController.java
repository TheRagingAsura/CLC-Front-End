package com.gcu;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.gcu.AppUser;


@Controller
public class LoginController 
{
    private final UserService userService;
    private final PostService postService;

    public LoginController(UserService userService, PostService postService)
    {
        this.userService = userService;
        this.postService = postService;
    }

    @GetMapping("/login")
    public String showLoginForm(Model model) 
    {
        model.addAttribute("user", new AppUser());
        return "login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute AppUser user, Model model)
    {
        if (userService.authenticate(user.getUsername(), user.getPassword()))
        {
            model.addAttribute("username", user.getUsername());
            model.addAttribute("posts", postService.getAllPosts());
            return "dashboard";
        }
        model.addAttribute("error", "Invalid login");
        return "login";
    }

}
