package com.gcu;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class UserService
{
    private Map<String, AppUser> users = new ConcurrentHashMap<>();

    // Make a new user; returns false if username exists
    public boolean registerUser(AppUser user)
    {
        if (users.containsKey(user.getUsername()))
        {
            return false; // Username taken
        }
        users.put(user.getUsername(), user);
        return true;
    }

    // Authenticate user by username and password
    public boolean authenticate(String username, String password) {
        AppUser user = users.get(username);
        if (user == null)
        {
            return false; // User not found
        }
        return user.getPassword().equals(password);
    }

}