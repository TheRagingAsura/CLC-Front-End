package com.gcu;

import com.gcu.Post;
import com.gcu.PostRepository;
import org.springframework.stereotype.Service;

@Service
public class PostService 
{

    private final PostRepository repo;

    public PostService(PostRepository repo) 
    {
        this.repo = repo;
    }

    public void createPost(Post post) 
    {
        repo.save(post);
    }

    public Iterable<Post> getAllPosts() 
    {
        return repo.findAll();
    }

    public Iterable<Post> getPostsByAuthor(String author)
    {
        return repo.findByAuthor(author);
    }

    public Post getPostById(Long id) {
        return repo.findById(id).orElse(null);
    }

    public void updatePost(Post post) {
        repo.save(post);
    }

    public void deletePost(Long id) {
        repo.deleteById(id);
    }

}
